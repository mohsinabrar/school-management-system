"use client"

import { useState } from "react"

export default function TeacherDashboard() {
  const classes = ["8-A", "8-B", "9-A"]
  const [fileName, setFileName] = useState("")

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Teacher Overview</h1>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">My Classes</h2>
          <ul className="space-y-2">
            {classes.map((c) => (
              <li key={c} className="rounded-md border px-3 py-2">
                {c}
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Mark Attendance</h2>
          <div className="space-y-2 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked /> Ava Johnson
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" /> Liam Smith
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked /> Noah Brown
            </label>
          </div>
          <button className="mt-3 rounded-md bg-blue-600 text-white px-3 py-2 hover:bg-blue-700">Save</button>
        </div>

        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Upload Assignment</h2>
          <input
            type="file"
            onChange={(e) => setFileName(e.target.files?.[0]?.name ?? "")}
            className="block w-full text-sm"
          />
          <div className="text-xs text-muted-foreground mt-2">{fileName || "No file chosen."}</div>
          <button className="mt-3 rounded-md bg-blue-600 text-white px-3 py-2 hover:bg-blue-700">Upload</button>
        </div>
      </div>

      <form className="rounded-lg border bg-card p-4 grid md:grid-cols-4 gap-3">
        <h2 className="text-sm font-medium md:col-span-4">Marks Entry</h2>
        <input className="rounded-md border px-3 py-2 bg-background" placeholder="Student" />
        <input className="rounded-md border px-3 py-2 bg-background" placeholder="Subject" />
        <input className="rounded-md border px-3 py-2 bg-background" type="number" placeholder="Marks" />
        <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Save</button>
      </form>
    </div>
  )
}
