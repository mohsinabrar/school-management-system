export default function ParentDashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Parent Overview</h1>

      <div className="grid lg:grid-cols-4 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Child</h2>
          <div className="text-sm">
            <div>
              <span className="font-medium">Name:</span> Ava Johnson
            </div>
            <div>
              <span className="font-medium">Class:</span> 8-A
            </div>
            <div>
              <span className="font-medium">Roll:</span> S001
            </div>
          </div>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Attendance</h2>
          <p className="text-sm text-foreground">This term: 94%</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Marks</h2>
          <ul className="text-sm space-y-1">
            <li>Math: 85</li>
            <li>Science: 78</li>
            <li>English: 88</li>
          </ul>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Fees</h2>
          <p className="text-sm">
            Status: <span className="rounded-md bg-green-100 text-green-700 px-2 py-1">Up to date</span>
          </p>
        </div>
      </div>

      <div className="rounded-lg border bg-card p-4">
        <h2 className="text-sm font-medium mb-2">Notices</h2>
        <ul className="text-sm space-y-2">
          <li className="rounded-md border px-3 py-2">PTA Meeting on Friday at 3pm</li>
          <li className="rounded-md border px-3 py-2 bg-blue-50 border-blue-200">Important: Exam Schedule Released</li>
        </ul>
      </div>
    </div>
  )
}
