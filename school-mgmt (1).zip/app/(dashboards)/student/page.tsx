export default function StudentDashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Student Overview</h1>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Profile</h2>
          <div className="text-sm">
            <div>
              <span className="font-medium">Name:</span> Ava Johnson
            </div>
            <div>
              <span className="font-medium">Class:</span> 8-A
            </div>
            <div>
              <span className="font-medium">Roll:</span> S001
            </div>
          </div>
        </div>
        <div className="rounded-lg border bg-card p-4 lg:col-span-2">
          <h2 className="text-sm font-medium mb-2">Timetable</h2>
          <div className="grid grid-cols-5 gap-2 text-sm">
            {["Math", "Science", "English", "History", "Computer"].map((s) => (
              <div key={s} className="rounded-md border px-2 py-2 text-center bg-muted">
                {s}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Assignments</h2>
          <ul className="text-sm space-y-2">
            <li className="rounded-md border px-3 py-2">Math Worksheet - Due Fri</li>
            <li className="rounded-md border px-3 py-2">English Essay - Due Mon</li>
          </ul>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Attendance</h2>
          <p className="text-sm text-foreground">This term: 94% present</p>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Marks</h2>
          <ul className="text-sm space-y-1">
            <li>Math: 85</li>
            <li>Science: 78</li>
            <li>English: 88</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
