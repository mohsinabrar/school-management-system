"use client"

import { useState } from "react"

type Row = { id: number; name: string; present: boolean }
const initial: Row[] = [
  { id: 1, name: "Ava Johnson", present: true },
  { id: 2, name: "Liam Smith", present: false },
  { id: 3, name: "Noah Brown", present: true },
]

export default function AttendancePage() {
  const [rows, setRows] = useState<Row[]>(initial)
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Attendance Management</h1>
      <div className="rounded-lg border bg-card overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-muted text-left">
            <tr>
              <th className="px-4 py-2 font-medium">Student</th>
              <th className="px-4 py-2 font-medium">Present</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="px-4 py-2">{r.name}</td>
                <td className="px-4 py-2">
                  <label className="inline-flex items-center gap-2">
                    <input
                      type="checkbox"
                      className="h-4 w-4"
                      checked={r.present}
                      onChange={(e) =>
                        setRows((prev) => prev.map((p) => (p.id === r.id ? { ...p, present: e.target.checked } : p)))
                      }
                    />
                    {r.present ? (
                      <span className="text-green-600">Present</span>
                    ) : (
                      <span className="text-foreground/70">Absent</span>
                    )}
                  </label>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="rounded-lg border bg-card p-4">
        <h2 className="text-sm font-medium mb-2">History (Student View)</h2>
        <p className="text-sm text-muted-foreground">Last 5 days: P, P, A, P, P</p>
      </div>
    </div>
  )
}
