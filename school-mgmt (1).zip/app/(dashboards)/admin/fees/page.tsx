"use client"

import { useState } from "react"

type FeeRow = { id: number; student: string; className: string; due: number; status: "Paid" | "Pending" }

const initial: FeeRow[] = [
  { id: 1, student: "Ava Johnson", className: "8-A", due: 0, status: "Paid" },
  { id: 2, student: "Liam Smith", className: "8-A", due: 150, status: "Pending" },
  { id: 3, student: "Noah Brown", className: "9-B", due: 300, status: "Pending" },
]

export default function FeesPage() {
  const [rows, setRows] = useState<FeeRow[]>(initial)
  function markPaid(id: number) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, status: "Paid", due: 0 } : r)))
  }
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Fees Management</h1>
      <div className="rounded-lg border bg-card overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-muted text-left">
            <tr>
              <th className="px-4 py-2 font-medium">Student</th>
              <th className="px-4 py-2 font-medium">Class</th>
              <th className="px-4 py-2 font-medium">Due</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="px-4 py-2">{r.student}</td>
                <td className="px-4 py-2">{r.className}</td>
                <td className="px-4 py-2">${r.due}</td>
                <td className="px-4 py-2">
                  {r.status === "Paid" ? (
                    <span className="rounded-md bg-green-100 text-green-700 px-2 py-1 text-xs">Paid</span>
                  ) : (
                    <span className="rounded-md bg-muted text-foreground px-2 py-1 text-xs">Pending</span>
                  )}
                </td>
                <td className="px-4 py-2">
                  {r.status === "Pending" ? (
                    <button
                      onClick={() => markPaid(r.id)}
                      className="rounded-md bg-blue-600 text-white px-3 py-1.5 hover:bg-blue-700"
                    >
                      Pay Now
                    </button>
                  ) : (
                    <button className="rounded-md border px-3 py-1.5">Download Receipt</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
