"use client"

import { useState } from "react"
import type React from "react"

type Teacher = { id: number; name: string; subject: string; contact: string }

const initial: Teacher[] = [
  { id: 1, name: "Emily Clark", subject: "Mathematics", contact: "555-0011" },
  { id: 2, name: "Jacob Miller", subject: "Science", contact: "555-2233" },
]

export default function TeachersPage() {
  const [teachers, setTeachers] = useState<Teacher[]>(initial)
  const [form, setForm] = useState({ name: "", subject: "", contact: "" })

  function addTeacher(e: React.FormEvent) {
    e.preventDefault()
    setTeachers([{ id: Date.now(), ...form }, ...teachers])
    setForm({ name: "", subject: "", contact: "" })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Teacher Management</h1>
      <form onSubmit={addTeacher} className="rounded-lg border bg-card p-4 grid md:grid-cols-4 gap-3">
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => setForm({ ...form, subject: e.target.value })}
          required
        />
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Contact"
          value={form.contact}
          onChange={(e) => setForm({ ...form, contact: e.target.value })}
          required
        />
        <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Add Teacher</button>
      </form>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {teachers.map((t) => (
          <div key={t.id} className="rounded-lg border bg-card p-4">
            <div className="font-medium">{t.name}</div>
            <div className="text-sm text-muted-foreground">{t.subject}</div>
            <div className="text-sm text-muted-foreground mt-1">{t.contact}</div>
            <div className="mt-3 flex gap-2">
              <button className="text-blue-700 hover:underline text-sm">Profile</button>
              <button className="text-foreground/80 hover:underline text-sm">Edit</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
