export default function ClassesSubjectsPage() {
  const classes = ["6-A", "7-B", "8-A", "9-B", "10-A"]
  const subjects = ["Math", "Science", "English", "History", "Computer"]
  const timetable = [
    { day: "Mon", slots: ["Math", "Science", "English", "History", "Computer"] },
    { day: "Tue", slots: ["Science", "Math", "Computer", "English", "History"] },
  ]
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Classes & Subjects</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Classes</h2>
          <ul className="grid grid-cols-3 gap-2">
            {classes.map((c) => (
              <li key={c} className="rounded-md border px-3 py-2 text-sm bg-muted">
                {c}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Subjects</h2>
          <ul className="grid grid-cols-3 gap-2">
            {subjects.map((s) => (
              <li key={s} className="rounded-md border px-3 py-2 text-sm bg-muted">
                {s}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="rounded-lg border bg-card p-4">
        <h2 className="text-sm font-medium mb-3">Timetable</h2>
        <div className="overflow-x-auto">
          <table className="min-w-[640px] text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="px-3 py-2 text-left font-medium">Day</th>
                {[1, 2, 3, 4, 5].map((i) => (
                  <th key={i} className="px-3 py-2 text-left font-medium">
                    Period {i}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {timetable.map((row) => (
                <tr key={row.day} className="border-t">
                  <td className="px-3 py-2 font-medium">{row.day}</td>
                  {row.slots.map((s, i) => (
                    <td className="px-3 py-2" key={i}>
                      {s}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
