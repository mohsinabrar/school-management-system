"use client"

import { useState } from "react"
import type React from "react"

type Student = { id: number; name: string; roll: string; className: string; contact: string }

const initial: Student[] = [
  { id: 1, name: "Ava Johnson", roll: "S001", className: "8-A", contact: "555-1234" },
  { id: 2, name: "Liam Smith", roll: "S002", className: "8-A", contact: "555-5678" },
  { id: 3, name: "Noah Brown", roll: "S015", className: "9-B", contact: "555-8888" },
]

export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>(initial)
  const [form, setForm] = useState({ name: "", roll: "", className: "", contact: "" })

  function addStudent(e: React.FormEvent) {
    e.preventDefault()
    const next: Student = { id: Date.now(), ...form }
    setStudents((prev) => [next, ...prev])
    setForm({ name: "", roll: "", className: "", contact: "" })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Student Management</h1>

      <form onSubmit={addStudent} className="rounded-lg border bg-card p-4 grid md:grid-cols-5 gap-3">
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
        />
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Roll No"
          value={form.roll}
          onChange={(e) => setForm({ ...form, roll: e.target.value })}
          required
        />
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Class"
          value={form.className}
          onChange={(e) => setForm({ ...form, className: e.target.value })}
          required
        />
        <input
          className="rounded-md border px-3 py-2 bg-background"
          placeholder="Contact"
          value={form.contact}
          onChange={(e) => setForm({ ...form, contact: e.target.value })}
          required
        />
        <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Add Student</button>
      </form>

      <div className="rounded-lg border bg-card overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-muted text-left">
            <tr>
              <th className="px-4 py-2 font-medium">Name</th>
              <th className="px-4 py-2 font-medium">Roll No</th>
              <th className="px-4 py-2 font-medium">Class</th>
              <th className="px-4 py-2 font-medium">Contact</th>
              <th className="px-4 py-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="px-4 py-2">{s.name}</td>
                <td className="px-4 py-2">{s.roll}</td>
                <td className="px-4 py-2">{s.className}</td>
                <td className="px-4 py-2">{s.contact}</td>
                <td className="px-4 py-2">
                  <div className="flex gap-2">
                    <button className="text-blue-700 hover:underline">Profile</button>
                    <button className="text-foreground/80 hover:underline">Edit</button>
                    <button className="text-foreground/80 hover:underline">Remove</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
