"use client"

import { useState } from "react"
import type React from "react"

type Notice = { id: number; title: string; content: string; important?: boolean }

export default function NoticesPage() {
  const [form, setForm] = useState({ title: "", content: "", important: false })
  const [notices, setNotices] = useState<Notice[]>([
    { id: 1, title: "Exam Schedule Released", content: "Check the portal for details.", important: true },
    { id: 2, title: "Sports Day", content: "Practice sessions start next week." },
  ])

  function addNotice(e: React.FormEvent) {
    e.preventDefault()
    setNotices([{ id: Date.now(), ...form }, ...notices])
    setForm({ title: "", content: "", important: false })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Noticeboard</h1>

      <form onSubmit={addNotice} className="rounded-lg border bg-card p-4 grid gap-3">
        <div className="grid md:grid-cols-2 gap-3">
          <input
            className="rounded-md border px-3 py-2 bg-background"
            placeholder="Title"
            value={form.title}
            onChange={(e) => setForm((s) => ({ ...s, title: e.target.value }))}
            required
          />
          <label className="inline-flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.important}
              onChange={(e) => setForm((s) => ({ ...s, important: e.target.checked }))}
            />
            Mark as important
          </label>
        </div>
        <textarea
          className="rounded-md border px-3 py-2 min-h-24 bg-background"
          placeholder="Content"
          value={form.content}
          onChange={(e) => setForm((s) => ({ ...s, content: e.target.value }))}
          required
        />
        <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Post Notice</button>
      </form>

      <ul className="grid md:grid-cols-2 gap-4">
        {notices.map((n) => (
          <li key={n.id} className={`rounded-lg border p-4 bg-card ${n.important ? "bg-blue-50 border-blue-200" : ""}`}>
            <div className="font-medium">{n.title}</div>
            <p className="text-sm text-foreground mt-1">{n.content}</p>
            {n.important ? <div className="text-xs mt-2 text-blue-800">Important</div> : null}
          </li>
        ))}
      </ul>
    </div>
  )
}
