"use client"

import { useState } from "react"
import type React from "react"

type ExamRow = { id: number; subject: string; date: string; time: string }
const timetable: ExamRow[] = [
  { id: 1, subject: "Math", date: "2025-09-10", time: "10:00 AM" },
  { id: 2, subject: "Science", date: "2025-09-12", time: "10:00 AM" },
  { id: 3, subject: "English", date: "2025-09-15", time: "10:00 AM" },
]

export default function ExamsResultsPage() {
  const [marks, setMarks] = useState({ student: "", subject: "", marks: "" })

  function submitMarks(e: React.FormEvent) {
    e.preventDefault()
    alert(`Saved marks: ${marks.student} - ${marks.subject} - ${marks.marks}`)
    setMarks({ student: "", subject: "", marks: "" })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Exam & Result Management</h1>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="rounded-lg border bg-card overflow-hidden">
          <div className="p-4 border-b">
            <h2 className="text-sm font-medium">Exam Timetable</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-muted text-left">
                <tr>
                  <th className="px-4 py-2 font-medium">Subject</th>
                  <th className="px-4 py-2 font-medium">Date</th>
                  <th className="px-4 py-2 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {timetable.map((t) => (
                  <tr key={t.id} className="border-t">
                    <td className="px-4 py-2">{t.subject}</td>
                    <td className="px-4 py-2">{t.date}</td>
                    <td className="px-4 py-2">{t.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <form onSubmit={submitMarks} className="rounded-lg border bg-card p-4 grid gap-3">
          <h2 className="text-sm font-medium">Marks Entry</h2>
          <input
            className="rounded-md border px-3 py-2 bg-background"
            placeholder="Student Name"
            value={marks.student}
            onChange={(e) => setMarks((s) => ({ ...s, student: e.target.value }))}
            required
          />
          <input
            className="rounded-md border px-3 py-2 bg-background"
            placeholder="Subject"
            value={marks.subject}
            onChange={(e) => setMarks((s) => ({ ...s, subject: e.target.value }))}
            required
          />
          <input
            className="rounded-md border px-3 py-2 bg-background"
            type="number"
            placeholder="Marks"
            value={marks.marks}
            onChange={(e) => setMarks((s) => ({ ...s, marks: e.target.value }))}
            required
          />
          <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Save</button>
        </form>
      </div>

      <div className="rounded-lg border bg-card p-4">
        <h2 className="text-sm font-medium mb-3">Student Report Card</h2>
        <div className="grid sm:grid-cols-2 gap-4 text-sm">
          <div>
            <div>
              <span className="font-medium">Name:</span> Ava Johnson
            </div>
            <div>
              <span className="font-medium">Class:</span> 8-A
            </div>
            <div>
              <span className="font-medium">Roll No:</span> S001
            </div>
          </div>
          <div>
            <div>
              <span className="font-medium">Term:</span> Mid-Term
            </div>
            <div>
              <span className="font-medium">Attendance:</span> 94%
            </div>
            <div>
              <span className="font-medium">Result:</span> Pass
            </div>
          </div>
        </div>
        <div className="mt-3 overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-muted text-left">
              <tr>
                <th className="px-3 py-2 font-medium">Subject</th>
                <th className="px-3 py-2 font-medium">Marks</th>
                <th className="px-3 py-2 font-medium">Grade</th>
              </tr>
            </thead>
            <tbody>
              {[
                { subject: "Math", marks: 85, grade: "A" },
                { subject: "Science", marks: 78, grade: "B+" },
                { subject: "English", marks: 88, grade: "A" },
              ].map((r) => (
                <tr key={r.subject} className="border-t">
                  <td className="px-3 py-2">{r.subject}</td>
                  <td className="px-3 py-2">{r.marks}</td>
                  <td className="px-3 py-2">{r.grade}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
