import { StatCard } from "@/components/common/stat-card"
import { AttendancePie } from "@/components/charts/attendance-pie"
import { FeeTrendLine } from "@/components/charts/fee-trend-line"
import { ExamPerformanceBar } from "@/components/charts/exam-performance-bar"

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard title="Total Students" value={1240} />
        <StatCard title="Teachers" value={86} />
        <StatCard title="Classes" value={42} />
        <StatCard title="Revenue (M)" value="$1.2" hint="This quarter" />
        <StatCard title="Avg Attendance" value="92%" />
      </div>

      <section className="grid lg:grid-cols-3 gap-4">
        <div className="rounded-lg border bg-card p-4">
          <h2 className="text-sm font-medium mb-2">Attendance</h2>
          <AttendancePie />
        </div>
        <div className="rounded-lg border bg-card p-4 lg:col-span-2">
          <h2 className="text-sm font-medium mb-2">Fee Collection Trend</h2>
          <FeeTrendLine />
        </div>
        <div className="rounded-lg border bg-card p-4 lg:col-span-3">
          <h2 className="text-sm font-medium mb-2">Exam Performance</h2>
          <ExamPerformanceBar />
        </div>
      </section>

      <section className="rounded-lg border bg-card p-4">
        <h2 className="text-sm font-medium mb-3">Notices</h2>
        <ul className="space-y-2">
          <li className="rounded-md border px-3 py-2">
            <span className="font-medium">PTA Meeting on Friday</span>
            <p className="text-sm text-muted-foreground">All parents of grade 6-8 invited at 3pm in auditorium.</p>
          </li>
          <li className="rounded-md border px-3 py-2 bg-blue-50 border-blue-200">
            <span className="font-medium text-blue-900">Important: Exam Schedule Released</span>
            <p className="text-sm text-foreground">Mid-term exam dates are published on the portal.</p>
          </li>
        </ul>
      </section>
    </div>
  )
}
