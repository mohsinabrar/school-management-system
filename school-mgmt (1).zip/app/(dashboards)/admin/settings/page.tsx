"use client"

import { useState } from "react"

export default function SettingsPage() {
  const [profile, setProfile] = useState({ name: "Admin User", email: "admin@school.edu" })
  const [school, setSchool] = useState({ name: "Your School", theme: "blue", logo: "" })

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Settings</h1>

      <div className="grid lg:grid-cols-2 gap-4">
        <form className="rounded-lg border bg-card p-4 grid gap-3">
          <h2 className="text-sm font-medium">Profile</h2>
          <input
            className="rounded-md border px-3 py-2 bg-background"
            value={profile.name}
            onChange={(e) => setProfile((s) => ({ ...s, name: e.target.value }))}
          />
          <input
            className="rounded-md border px-3 py-2 bg-background"
            value={profile.email}
            onChange={(e) => setProfile((s) => ({ ...s, email: e.target.value }))}
          />
          <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Save</button>
        </form>

        <form className="rounded-lg border bg-card p-4 grid gap-3">
          <h2 className="text-sm font-medium">School Info</h2>
          <input
            className="rounded-md border px-3 py-2 bg-background"
            value={school.name}
            onChange={(e) => setSchool((s) => ({ ...s, name: e.target.value }))}
            placeholder="School Name"
          />
          <label className="block">
            <span className="text-sm font-medium">Theme Color</span>
            <select
              className="mt-1 w-full rounded-md border px-3 py-2 bg-background"
              value={school.theme}
              onChange={(e) => setSchool((s) => ({ ...s, theme: e.target.value }))}
            >
              <option value="blue">Blue</option>
              <option value="gray">Gray</option>
              <option value="green">Green</option>
            </select>
          </label>
          <label className="block">
            <span className="text-sm font-medium">Logo</span>
            <input type="file" className="mt-1 block w-full" />
          </label>
          <button className="rounded-md bg-blue-600 text-white px-4 py-2 hover:bg-blue-700">Save</button>
        </form>
      </div>
    </div>
  )
}
