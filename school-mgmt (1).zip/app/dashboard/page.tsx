import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const Stat = ({ label, value }: { label: string; value: string }) => (
  <Card>
    <CardHeader className="pb-2">
      <CardTitle className="text-sm text-muted-foreground">{label}</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-2xl font-semibold">{value}</p>
    </CardContent>
  </Card>
)

export default function DashboardPage() {
  return (
    <main className="min-h-dvh px-6 py-8">
      <div className="mx-auto max-w-6xl space-y-8">
        <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <h1 className="text-2xl md:text-3xl font-semibold text-balance">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Demo data only</p>
        </header>

        {/* Stats */}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Total Students" value="1,248" />
          <Stat label="Teachers" value="86" />
          <Stat label="Classes" value="42" />
          <Stat label="Pending Fees" value="$12,430" />
        </section>

        {/* Recent activity table */}
        <section className="grid gap-3">
          <h2 className="text-lg font-medium">Recent Activity</h2>
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-secondary">
                <tr className="text-left">
                  <th className="px-4 py-2">Date</th>
                  <th className="px-4 py-2">Type</th>
                  <th className="px-4 py-2">Details</th>
                  <th className="px-4 py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { date: "Sep 1", type: "Fee", details: "Invoice #10241 paid", status: "Success" },
                  { date: "Aug 30", type: "Attendance", details: "Class 8A marked", status: "Complete" },
                  { date: "Aug 30", type: "Exam", details: "Math results published", status: "Published" },
                  { date: "Aug 29", type: "Notice", details: "PTA meeting announced", status: "Sent" },
                ].map((row, idx) => (
                  <tr key={idx} className="border-t">
                    <td className="px-4 py-2">{row.date}</td>
                    <td className="px-4 py-2">{row.type}</td>
                    <td className="px-4 py-2">{row.details}</td>
                    <td className="px-4 py-2">
                      <span className="inline-flex items-center rounded-md bg-accent/15 px-2 py-1 text-xs text-accent">
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </main>
  )
}
