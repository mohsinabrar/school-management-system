"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useState } from "react"

const roles = [
  { label: "Admin", value: "admin" },
  { label: "Teacher", value: "teacher" },
  { label: "Student", value: "student" },
  { label: "Parent", value: "parent" },
]

export default function LoginPage() {
  const router = useRouter()
  const [role, setRole] = useState("admin")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    // Basic client-side validation
    const isEmailValid = /\S+@\S+\.\S+/.test(email)
    if (!isEmailValid) {
      setError("Please enter a valid email address.")
      return
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.")
      return
    }

    try {
      setIsLoading(true)
      // Simulate a short async auth call
      setTimeout(() => {
        // You can replace this with real auth later
        router.push(`/${role}`)
        setIsLoading(false)
      }, 600)
    } catch (err) {
      setIsLoading(false)
      setError("Something went wrong. Please try again.")
    }
  }

  return (
    <main className="min-h-dvh grid place-items-center px-6">
      <section className="w-full max-w-md bg-card rounded-lg border p-6 shadow-sm">
        <h1 className="text-2xl font-semibold mb-1">Login</h1>
        <p className="text-sm text-muted-foreground mb-6">Choose role and sign in with dummy credentials.</p>
        <form className="space-y-4" onSubmit={onSubmit} noValidate>
          <label className="block">
            <span className="text-sm font-medium">Role</span>
            <select
              className="mt-1 block w-full rounded-md border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-background"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              {roles.map((r) => (
                <option key={r.value} value={r.value}>
                  {r.label}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="text-sm font-medium">Email</span>
            <input
              type="email"
              className="mt-1 block w-full rounded-md border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-background"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              aria-label="Email"
            />
          </label>

          <label className="block">
            <span className="text-sm font-medium">Password</span>
            <input
              type="password"
              className="mt-1 block w-full rounded-md border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-background"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              aria-label="Password"
            />
          </label>

          {/* error message (accessible) */}
          {error ? (
            <p className="text-sm text-red-600" role="alert" aria-live="assertive">
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            className="w-full rounded-md bg-blue-600 text-white py-2.5 hover:bg-blue-700 transition disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            disabled={isLoading}
            aria-busy={isLoading}
          >
            {isLoading ? (
              <>
                <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" aria-hidden="true">
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                    fill="none"
                  />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
                </svg>
                Signing in...
              </>
            ) : (
              "Continue"
            )}
          </button>
        </form>

        <p className="text-sm text-center mt-4">
          New user?{" "}
          <a href="/register" className="text-blue-700 hover:underline">
            Create an account
          </a>
        </p>
      </section>
    </main>
  )
}
