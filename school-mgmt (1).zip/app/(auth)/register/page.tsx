"use client"

import type React from "react"

import { useRouter } from "next/navigation"
import { useState } from "react"

export default function RegisterPage() {
  const router = useRouter()
  const [role, setRole] = useState("student")

  function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    router.push(`/${role}`)
  }

  return (
    <main className="min-h-dvh grid place-items-center px-6">
      <section className="w-full max-w-md bg-card rounded-lg border p-6 shadow-sm">
        <h1 className="text-2xl font-semibold mb-1">Register</h1>
        <p className="text-sm text-muted-foreground mb-6">Create a new account with a role.</p>
        <form className="space-y-4" onSubmit={onSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="block">
              <span className="text-sm font-medium">First name</span>
              <input
                className="mt-1 w-full rounded-md border px-3 py-2 focus:ring-2 focus:ring-blue-600 bg-background"
                required
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium">Last name</span>
              <input
                className="mt-1 w-full rounded-md border px-3 py-2 focus:ring-2 focus:ring-blue-600 bg-background"
                required
              />
            </label>
          </div>
          <label className="block">
            <span className="text-sm font-medium">Email</span>
            <input
              type="email"
              className="mt-1 w-full rounded-md border px-3 py-2 focus:ring-2 focus:ring-blue-600 bg-background"
              required
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Password</span>
            <input
              type="password"
              className="mt-1 w-full rounded-md border px-3 py-2 focus:ring-2 focus:ring-blue-600 bg-background"
              required
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium">Role</span>
            <select
              className="mt-1 block w-full rounded-md border px-3 py-2 focus:ring-2 focus:ring-blue-600 bg-background"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              <option value="admin">Admin</option>
              <option value="teacher">Teacher</option>
              <option value="student">Student</option>
              <option value="parent">Parent</option>
            </select>
          </label>
          <button
            type="submit"
            className="w-full rounded-md bg-blue-600 text-white py-2.5 hover:bg-blue-700 transition"
          >
            Create account
          </button>
        </form>
      </section>
    </main>
  )
}
