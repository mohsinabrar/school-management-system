import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <main className="min-h-dvh flex flex-col">
      {/* Top bar */}
      <header className="w-full border-b bg-card/60 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="mx-auto max-w-5xl px-6 py-4 flex items-center justify-between">
          <Link href="/" className="font-semibold text-lg">
            School<span className="text-primary">Manage</span>
          </Link>
          <nav className="flex items-center gap-3">
            <Link href="/dashboard" className="text-sm text-muted-foreground hover:text-foreground transition">
              Demo
            </Link>
            <Button asChild>
              <Link href="/login">Login</Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="flex-1 grid place-items-center">
        <div className="mx-auto max-w-5xl px-6 py-12 md:py-16 grid gap-10 md:grid-cols-2 items-center">
          <div className="space-y-5">
            <h1 className="text-balance text-3xl md:text-5xl font-semibold leading-tight">
              All-in-one School Management System
            </h1>
            <p className="text-pretty text-muted-foreground md:text-lg leading-relaxed">
              Manage students, teachers, classes, attendance, fees, exams, and more — in a fast, modern interface.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <Button asChild>
                <Link href="/login">Get Started</Link>
              </Button>
              <Button asChild className="bg-accent text-accent-foreground hover:opacity-90" variant="secondary">
                <Link href="/dashboard">Live Demo</Link>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">No signup required for the demo.</p>
          </div>

          {/* Feature cards */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Students & Classes</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Enroll students, assign classes, and manage timetables effortlessly.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Attendance & Exams</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Track attendance and publish results with clear reports.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Fees & Invoices</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Generate invoices, record payments, and monitor dues.
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Announcements</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                Keep everyone informed with notices and events.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t">
        <div className="mx-auto max-w-5xl px-6 py-6 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} SchoolManage. All rights reserved.
        </div>
      </footer>
    </main>
  )
}
