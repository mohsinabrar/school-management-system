"use client"

import { Bar, BarChart, Tooltip, XAxis, YAxis, ResponsiveContainer, CartesianGrid } from "recharts"

const data = [
  { subject: "Math", avg: 78 },
  { subject: "Science", avg: 74 },
  { subject: "English", avg: 82 },
  { subject: "History", avg: 69 },
  { subject: "Computer", avg: 88 },
]

export function ExamPerformanceBar() {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="subject" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="avg" fill="#10b981" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
