"use client"

import { Line, LineChart, Tooltip, XAxis, YAxis, ResponsiveContainer, CartesianGrid } from "recharts"

const data = [
  { month: "Jan", amount: 12000 },
  { month: "Feb", amount: 14000 },
  { month: "Mar", amount: 16000 },
  { month: "Apr", amount: 15000 },
  { month: "May", amount: 18000 },
  { month: "Jun", amount: 20000 },
]

export function FeeTrendLine() {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="amount" stroke="#1d4ed8" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
