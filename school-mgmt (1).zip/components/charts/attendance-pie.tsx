"use client"

import { Pie, PieChart, Cell, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: "Present", value: 92 },
  { name: "Absent", value: 8 },
]

// Palette: green accent and gray neutral
const COLORS = ["#10b981", "#6b7280"]

export function AttendancePie() {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie dataKey="value" data={data} innerRadius={50} outerRadius={70} paddingAngle={2}>
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
