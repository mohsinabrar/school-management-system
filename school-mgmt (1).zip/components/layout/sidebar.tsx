"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

type NavItem = { href: string; label: string }

export function Sidebar({ title, items }: { title: string; items: NavItem[] }) {
  const pathname = usePathname()
  return (
    <aside className="hidden md:flex md:w-64 md:flex-col border-r bg-card">
      <div className="h-14 flex items-center px-4 border-b">
        <span className="font-semibold">{title}</span>
      </div>
      <nav className="flex-1 p-2">
        <ul className="space-y-1">
          {items.map((it) => {
            const active = pathname === it.href
            return (
              <li key={it.href}>
                <Link
                  href={it.href}
                  className={cn(
                    "block rounded-md px-3 py-2 text-sm hover:bg-blue-50",
                    active ? "bg-blue-100 text-blue-800 font-medium" : "text-foreground/80",
                  )}
                >
                  {it.label}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
      <div className="p-3 text-xs text-muted-foreground">© 2025 Your School</div>
    </aside>
  )
}
