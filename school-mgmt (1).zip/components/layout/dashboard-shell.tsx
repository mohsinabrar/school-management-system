"use client"

import { usePathname } from "next/navigation"
import { Sidebar } from "./sidebar"
import { Topbar } from "./topbar"
import type { ReactNode } from "react"

const NAV: Record<string, { title: string; items: { href: string; label: string }[] }> = {
  admin: {
    title: "Admin Panel",
    items: [
      { href: "/admin", label: "Overview" },
      { href: "/admin/students", label: "Students" },
      { href: "/admin/teachers", label: "Teachers" },
      { href: "/admin/classes-subjects", label: "Classes & Subjects" },
      { href: "/admin/attendance", label: "Attendance" },
      { href: "/admin/fees", label: "Fees" },
      { href: "/admin/exams-results", label: "Exams & Results" },
      { href: "/admin/notices", label: "Noticeboard" },
      { href: "/admin/settings", label: "Settings" },
    ],
  },
  teacher: {
    title: "Teacher Panel",
    items: [
      { href: "/teacher", label: "Overview" },
      { href: "/teacher/classes", label: "My Classes" },
      { href: "/teacher/attendance", label: "Mark Attendance" },
      { href: "/teacher/assignments", label: "Assignments" },
      { href: "/teacher/marks", label: "Marks Entry" },
      { href: "/teacher/notices", label: "Notices" },
    ],
  },
  student: {
    title: "Student Panel",
    items: [
      { href: "/student", label: "Overview" },
      { href: "/student/timetable", label: "Timetable" },
      { href: "/student/assignments", label: "Assignments" },
      { href: "/student/attendance", label: "Attendance" },
      { href: "/student/results", label: "Results" },
      { href: "/student/notices", label: "Notices" },
    ],
  },
  parent: {
    title: "Parent Panel",
    items: [
      { href: "/parent", label: "Overview" },
      { href: "/parent/attendance", label: "Child Attendance" },
      { href: "/parent/results", label: "Child Results" },
      { href: "/parent/fees", label: "Fees Status" },
      { href: "/parent/notices", label: "Notices" },
    ],
  },
}

function getRole(path: string) {
  if (path.startsWith("/admin")) return "admin"
  if (path.startsWith("/teacher")) return "teacher"
  if (path.startsWith("/student")) return "student"
  if (path.startsWith("/parent")) return "parent"
  return "admin"
}

export function DashboardShell({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const role = getRole(pathname)
  const config = NAV[role]

  return (
    <div className="min-h-dvh grid md:grid-cols-[16rem_1fr]">
      <Sidebar title={config.title} items={config.items} />
      <div className="flex flex-col">
        <Topbar title="Dashboard" />
        <main className="p-4 md:p-6 bg-muted/30">{children}</main>
      </div>
    </div>
  )
}
