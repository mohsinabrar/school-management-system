"use client"

import { Bell, Search, User } from "lucide-react"

export function Topbar({ title }: { title: string }) {
  return (
    <header className="h-14 w-full border-b bg-card">
      <div className="h-full flex items-center justify-between px-4 gap-3">
        <h1 className="text-lg font-semibold">{title}</h1>
        <div className="flex items-center gap-3">
          <label className="relative hidden md:block">
            <span className="sr-only">Search</span>
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              className="pl-8 pr-3 py-2 rounded-md border text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 bg-background"
              placeholder="Search..."
              aria-label="Search"
            />
          </label>
          <button
            aria-label="Notifications"
            className="inline-flex items-center justify-center h-9 w-9 rounded-md border hover:bg-muted"
          >
            <Bell className="h-5 w-5" />
          </button>
          <button className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-muted">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Profile</span>
          </button>
        </div>
      </div>
    </header>
  )
}
